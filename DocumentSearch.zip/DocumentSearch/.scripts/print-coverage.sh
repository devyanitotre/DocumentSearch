#!/usr/bin/env bash
# Prints JaCoCo line coverage % from target/site/jacoco/jacoco.xml.
# Run from project root (Maven antrun does this).

cd "$(dirname "$0")/.." || exit 0
JACOCO_XML="target/site/jacoco/jacoco.xml"
if [[ ! -f "$JACOCO_XML" ]]; then
  echo "[INFO] Coverage report not found (run mvn verify). See target/site/jacoco/index.html if report exists."
  exit 0
fi

awk '/type="LINE"/{
  if (match($0, /missed="[0-9]+"/)) { missed += substr($0, RSTART+9, RLENGTH-10)+0 }
  if (match($0, /covered="[0-9]+"/)) { covered += substr($0, RSTART+10, RLENGTH-11)+0 }
}
END {
  total = missed + covered
  if (total > 0)
    printf "\n[INFO] Test coverage (lines): %.1f%% (%d/%d)\n[INFO] Report: target/site/jacoco/index.html\n\n", 100*covered/total, covered, total
  else
    print "\n[INFO] Test coverage: N/A (no instrumented lines)\n"
}' "$JACOCO_XML"
