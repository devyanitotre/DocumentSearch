package search;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Stream;


public class DocumentSearchApp {

    private static final Logger log = LoggerFactory.getLogger(DocumentSearchApp.class);

    public static void main(String[] args) throws IOException {
        String documentsDir = Config.getDocumentsDir();
        System.out.println("========================================");
        System.out.println("        DOCUMENT SEARCH ENGINE          ");
        System.out.println("========================================\n");

        LoadResult loadResult = loadDocuments(documentsDir);
        if (loadResult.isEmpty()) {
            System.out.println("No documents found in '" + documentsDir + "'. Exiting.");
            return;
        }
        if (loadResult.hasFailures()) {
            System.out.println("Warning: " + loadResult.getFailedPaths().size() + " file(s) could not be loaded:");
            for (Path p : loadResult.getFailedPaths()) {
                System.out.println("  - " + p);
            }
            System.out.println("Searching the " + loadResult.getDocuments().size() + " loaded document(s) only.\n");
        }

        List<Document> documents = loadResult.getDocuments();
        System.out.println("Loaded " + documents.size() + " document(s):");
        for (Document doc : documents) {
            System.out.println("  - " + doc.getFileName());
        }
        System.out.println();

        Map<String, Searcher> searchers = new LinkedHashMap<>();
        searchers.put("1", new StringSearcher());
        searchers.put("2", new RegexSearcher());
        searchers.put("3", new IndexedSearcher());
        for (Searcher s : searchers.values()) {
            s.index(documents);
        }
        Map<String, String> methodNames = Map.of(
            "1", "String Match",
            "2", "Regular Expression",
            "3", "Indexed Search"
        );

        DocumentSearchService service = new DocumentSearchService(searchers, methodNames);
        try (Scanner scanner = new Scanner(System.in)) {
            service.runInteractive(scanner, documents, System.out);
        }
    }

 
    static LoadResult loadDocuments(String directoryPath) throws IOException {
        List<Document> documents = new ArrayList<>();
        List<Path> failedPaths = new ArrayList<>();
        Path dir = Paths.get(directoryPath);

        if (!Files.exists(dir) || !Files.isDirectory(dir)) {
            log.warn("Documents directory not found: {}", directoryPath);
            return new LoadResult(documents, failedPaths);
        }

        try (Stream<Path> paths = Files.list(dir)) {
            paths.filter(p -> p.toString().endsWith(".txt"))
                 .sorted()
                 .forEach(p -> {
                     try {
                         documents.add(new Document(p));
                     } catch (IOException e) {
                         log.warn("Could not read file: {} - {}", p, e.getMessage());
                         failedPaths.add(p);
                     }
                 });
        }
        return new LoadResult(documents, failedPaths);
    }
}
