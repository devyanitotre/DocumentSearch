package search;

/**
 * Represents one search result: which file matched, and how many times.
 * Implements Comparable so results can be sorted by match count (highest first).
 */
public class SearchResult implements Comparable<SearchResult> {

    private final String fileName;
    private final int matchCount;

    public SearchResult(String fileName, int matchCount) {
        this.fileName = fileName;
        this.matchCount = matchCount;
    }

    public String getFileName() {
        return fileName;
    }

    public int getMatchCount() {
        return matchCount;
    }

    /**
     * Orders by relevance: descending by match count (most matches first),
     * then ascending by file name for ties. Used by {@link java.util.Collections#sort}.
     */
    @Override
    public int compareTo(SearchResult other) {
        int countCompare = Integer.compare(other.matchCount, this.matchCount);
        if (countCompare != 0) return countCompare;
        return this.fileName.compareTo(other.fileName);
    }

    @Override
    public String toString() {
        return String.format("  %-35s – %d match%s", fileName, matchCount, matchCount == 1 ? "" : "es");
    }
}
