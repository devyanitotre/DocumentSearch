package search;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Represents a single document (text file). Content is loaded once and held in memory.
 * Use {@link #getContentLowerCase()} for case-insensitive search to get consistent
 * behavior across locales (e.g. Turkish "i").
 */
public class Document {

    private final String fileName;
    private final String content;

    public Document(Path filePath) throws IOException {
        this.fileName = filePath.getFileName().toString();
        this.content = Files.readString(filePath);
    }

    public String getFileName() {
        return fileName;
    }

    public String getContent() {
        return content;
    }

    /**
     * Returns content lowercased with {@link Locale#ROOT} for case-insensitive search.
     * Locale.ROOT avoids locale-dependent behavior (e.g. Turkish dotless i).
     */
    public String getContentLowerCase() {
        return content.toLowerCase(Locale.ROOT);
    }
}
