package search;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


public class IndexedSearcher implements Searcher {

    private static final int INITIAL_INDEX_CAPACITY = 1024;
    private static final int INITIAL_FILE_COUNTS_CAPACITY = 16;
    private static final Map<String, Integer> EMPTY_FILE_COUNTS = Collections.emptyMap();

    private final Map<String, Map<String, Integer>> index = new ConcurrentHashMap<>(INITIAL_INDEX_CAPACITY);
    private volatile boolean indexBuilt = false;
    private final Object buildLock = new Object();

    /**
     * Builds the index from the provided documents. Idempotent for the same
     * document list;
     */
    public void buildIndex(List<Document> documents) {
        if (documents == null || documents.isEmpty()) {
            return;
        }
        index.clear();
        for (Document doc : documents) {
            for (String word : TextAnalyzer.tokenize(doc.getContent())) {
                Map<String, Integer> fileCounts = index.computeIfAbsent(
                    word, k -> new ConcurrentHashMap<>(INITIAL_FILE_COUNTS_CAPACITY));
                fileCounts.merge(doc.getFileName(), 1, Integer::sum);
            }
        }
        indexBuilt = true;
    }

    @Override
    public List<SearchResult> search(String term, List<Document> documents) {
        if (documents == null || documents.isEmpty()) {
            return List.of();
        }
        synchronized (buildLock) {
            if (!indexBuilt) {
                buildIndex(documents);
            }
        }
        String termLower = TextAnalyzer.normalizeTerm(term);
        Map<String, Integer> fileCounts = index.getOrDefault(termLower, EMPTY_FILE_COUNTS);
        List<SearchResult> results = new ArrayList<>(fileCounts.size());
        for (Map.Entry<String, Integer> entry : fileCounts.entrySet()) {
            results.add(new SearchResult(entry.getKey(), entry.getValue()));
        }
        Collections.sort(results);
        return results;
    }

    @Override
    public void index(List<Document> documents) {
        buildIndex(documents);
    }

    /** Clears the index so the next search will rebuild it (e.g. after documents change). */
    public void clearIndex() {
        synchronized (buildLock) {
            index.clear();
            indexBuilt = false;
        }
    }
}
