package search;


public final class Config {

    private static final String PREFIX = "document.search.";

    private Config() { }

    public static String getDocumentsDir() {
        return firstNonBlank(
            System.getProperty(PREFIX + "documents.dir"),
            System.getenv("DOCUMENTS_DIR"),
            "documents"
        );
    }

    public static int getMaxSearchResults() {
        String v = firstNonBlank(
            System.getProperty(PREFIX + "max.results"),
            System.getenv("MAX_SEARCH_RESULTS"),
            "0"
        );
        try {
            int n = Integer.parseInt(v.trim());
            return n >= 0 ? n : 0;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static int getPatternCacheMaxSize() {
        String v = firstNonBlank(
            System.getProperty(PREFIX + "pattern.cache.size"),
            System.getenv("PATTERN_CACHE_SIZE"),
            "1000"
        );
        try {
            int n = Integer.parseInt(v.trim());
            return n > 0 ? n : 1000;
        } catch (NumberFormatException e) {
            return 1000;
        }
    }

    private static String firstNonBlank(String... values) {
        for (String s : values) {
            if (s != null && !s.isBlank()) return s;
        }
        return null;
    }
}
