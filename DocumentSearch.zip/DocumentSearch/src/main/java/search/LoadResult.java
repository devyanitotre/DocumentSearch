package search;

import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

/**
 * Result of loading documents from a directory: successfully loaded documents
 * and any paths that failed to load so callers can detect incomplete corpus.
 */
public final class LoadResult {

    private final List<Document> documents;
    private final List<Path> failedPaths;

    public LoadResult(List<Document> documents, List<Path> failedPaths) {
        this.documents = documents == null ? List.of() : List.copyOf(documents);
        this.failedPaths = failedPaths == null ? List.of() : List.copyOf(failedPaths);
    }

    public List<Document> getDocuments() {
        return documents;
    }

    public List<Path> getFailedPaths() {
        return failedPaths;
    }

    public boolean hasFailures() {
        return !failedPaths.isEmpty();
    }

    public boolean isEmpty() {
        return documents.isEmpty();
    }
}
