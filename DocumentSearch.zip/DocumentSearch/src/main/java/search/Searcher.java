package search;

import java.util.List;


public interface Searcher {

 
    default void index(List<Document> documents) {
    }

   
    List<SearchResult> search(String term, List<Document> documents);
}
