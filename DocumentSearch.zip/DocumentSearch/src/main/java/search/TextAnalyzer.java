package search;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Tokenizes and normalizes text for indexing and search.
 * Uses {@link Locale#ROOT} for lowercasing to avoid locale-dependent behavior (e.g. Turkish i).
 * <p>
 * <b>Limitations:</b> Matches literal tokens only. There is no stemming (e.g. "run",
 * "running", "runs" are different terms), no stop-word removal, and no lemmatization.
 * Tokenization splits on non-letters (ASCII); Unicode letters and other scripts are
 * not treated as word characters. For production search you would typically add
 * a stemmer, stop-word list, and possibly positional indexing for phrase search.
 */
public final class TextAnalyzer {

    private static final Locale NORMALIZE_LOCALE = Locale.ROOT;

    private TextAnalyzer() { }

    /**
     * Normalizes a term for case-insensitive matching (e.g. for index lookup).
     */
    public static String normalizeTerm(String term) {
        return term == null ? "" : term.toLowerCase(NORMALIZE_LOCALE);
    }

    /**
     * Splits text into words: non-empty sequences of ASCII letters, lowercased with Locale.ROOT.
     * Splits on any non-letter (spaces, punctuation, digits, etc.).
     */
    public static List<String> tokenize(String text) {
        if (text == null || text.isEmpty()) {
            return List.of();
        }
        String normalized = text.toLowerCase(NORMALIZE_LOCALE);
        return Arrays.stream(normalized.split("[^a-zA-Z]+"))
            .filter(w -> !w.isEmpty())
            .collect(Collectors.toList());
    }
}
