package search;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


public class DocumentSearchService {

    private static final Logger log = LoggerFactory.getLogger(DocumentSearchService.class);

    private final Map<String, Searcher> searchers;
    private final Map<String, String> methodNames;
    private final int maxResults;

    public DocumentSearchService(Map<String, Searcher> searchers, Map<String, String> methodNames) {
        this(searchers, methodNames, Config.getMaxSearchResults());
    }

    public DocumentSearchService(Map<String, Searcher> searchers, Map<String, String> methodNames, int maxResults) {
        this.searchers = new LinkedHashMap<>(searchers);
        this.methodNames = new LinkedHashMap<>(methodNames);
        this.maxResults = maxResults <= 0 ? Integer.MAX_VALUE : maxResults;
    }

    /**
     * Runs the interactive search loop: prompt for term and method, run search, print results.
     * Returns when the user enters quit or empty input.
     */
    public void runInteractive(Scanner scanner, List<Document> documents, Appendable out) {
        if (documents == null || documents.isEmpty()) {
            append(out, "No documents to search.\n");
            return;
        }
        while (true) {
            append(out, "Enter the search term (or 'quit' to exit): ");
            String term = scanner.nextLine();
            if (term != null) term = term.trim();
            if (term == null || term.isEmpty() || "quit".equalsIgnoreCase(term)) {
                append(out, "Goodbye!\n");
                break;
            }
            append(out, "\nSearch Method:\n  1) String Match\n  2) Regular Expression\n  3) Indexed Search\nChoose (1/2/3): ");
            String choice = scanner.nextLine();
            if (choice != null) choice = choice.trim();
            Searcher searcher = searchers.get(choice);
            if (searcher == null) {
                append(out, "Invalid choice. Please enter 1, 2, or 3.\n\n");
                continue;
            }
            append(out, "\n");
            long startNanos = System.nanoTime();
            List<SearchResult> results = searcher.search(term, documents);
            long elapsedNanos = System.nanoTime() - startNanos;
            long elapsedMs = elapsedNanos / 1_000_000;
            if (results.size() > maxResults) {
                results = results.subList(0, maxResults);
            }
            String methodName = methodNames.getOrDefault(choice, "Search");
            append(out, "Search results (" + methodName + ") for: \"" + term + "\"\n");
            append(out, "----------------------------------------\n");
            if (results.isEmpty()) {
                append(out, "  No matches found.\n");
            } else {
                for (SearchResult r : results) {
                    append(out, r.toString() + "\n");
                }
            }
            append(out, "----------------------------------------\n");
            append(out, "Elapsed time: " + elapsedMs + " ms\n\n");
        }
    }

    private static void append(Appendable out, String s) {
        try {
            out.append(s);
        } catch (java.io.IOException e) {
            log.warn("Failed to write output", e);
        }
    }
}
