package search;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 
 * Complexity: O(n·m) per document where n = text length, m = term length.
 * Suitable for small/medium documents; for very long texts consider
 * IndexedSearcher or algorithms like KMP/Boyer-Moore.
 */
public class StringSearcher implements Searcher {

    @Override
    public List<SearchResult> search(String term, List<Document> documents) {
        if (term == null || term.isEmpty() || documents == null || documents.isEmpty()) {
            return List.of();
        }
        String termLower = TextAnalyzer.normalizeTerm(term);
        List<SearchResult> results = new ArrayList<>();

        for (Document doc : documents) {
            int count = countOccurrences(doc.getContentLowerCase(), termLower);
            if (count > 0) {
                results.add(new SearchResult(doc.getFileName(), count));
            }
        }

        Collections.sort(results);
        return results;
    }

    /**
     * Counts occurrences of term in text using indexOf in a loop.
     * O(n·m) where n = text length, m = term length.
     */
    private int countOccurrences(String text, String term) {
        int count = 0;
        int index = 0;

        // indexOf finds the NEXT occurrence of term starting from 'index'
        // Returns -1 when there are no more matches
        while ((index = text.indexOf(term, index)) != -1) {
            count++;
            index += term.length(); // move past this match to find the next one
        }

        return count;
    }
}
