package search;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Word-boundary search using a regex: term is escaped so it is matched literally
 * as whole words only (e.g. "war" does not match "warp"). Case-insensitive.
 * Invalid input (e.g. that would break regex compilation) returns empty results
 * instead of throwing. Uses a bounded, thread-safe Caffeine cache for compiled patterns.
 */
public class RegexSearcher implements Searcher {

    private final Cache<String, Pattern> patternCache = Caffeine.newBuilder()
        .maximumSize(Config.getPatternCacheMaxSize())
        .build();

    @Override
    public List<SearchResult> search(String term, List<Document> documents) {
        if (term == null || term.isEmpty() || documents == null || documents.isEmpty()) {
            return List.of();
        }
        Pattern pattern = compileWordBoundaryPattern(term);
        if (pattern == null) {
            return List.of();
        }
        List<SearchResult> results = new ArrayList<>();
        for (Document doc : documents) {
            Matcher matcher = pattern.matcher(doc.getContent());
            int count = 0;
            while (matcher.find()) count++;
            if (count > 0) {
                results.add(new SearchResult(doc.getFileName(), count));
            }
        }
        Collections.sort(results);
        return results;
    }

    /**
     * Compiles a word-boundary pattern for the term (literal match, case-insensitive).
     * Returns null if compilation fails (e.g. invalid regex if term were ever unquoted).
     */
    private Pattern compileWordBoundaryPattern(String term) {
        String key = TextAnalyzer.normalizeTerm(term);
        Pattern cached = patternCache.getIfPresent(key);
        if (cached != null) {
            return cached;
        }
        try {
            Pattern p = Pattern.compile(
                "\\b" + Pattern.quote(term) + "\\b",
                Pattern.CASE_INSENSITIVE
            );
            patternCache.put(key, p);
            return p;
        } catch (PatternSyntaxException e) {
            return null;
        }
    }
}
