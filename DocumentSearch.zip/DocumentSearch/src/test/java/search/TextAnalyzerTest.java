package search;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TextAnalyzerTest {

    @Test
    @DisplayName("normalizeTerm lowercases with Locale.ROOT")
    void normalizeTerm() {
        assertEquals("war", TextAnalyzer.normalizeTerm("WAR"));
        assertEquals("war", TextAnalyzer.normalizeTerm("war"));
        assertEquals("", TextAnalyzer.normalizeTerm(null));
        assertEquals("", TextAnalyzer.normalizeTerm(""));
    }

    @Test
    @DisplayName("tokenize splits on non-letters and lowercases")
    void tokenize() {
        assertEquals(List.of("the", "cat", "sat"), TextAnalyzer.tokenize("The cat sat"));
        assertEquals(List.of("don", "t"), TextAnalyzer.tokenize("don't")); // split on apostrophe
        assertTrue(TextAnalyzer.tokenize("").isEmpty());
        assertTrue(TextAnalyzer.tokenize(null).isEmpty());
    }
}
