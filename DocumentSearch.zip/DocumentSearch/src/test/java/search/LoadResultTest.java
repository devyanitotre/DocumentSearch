package search;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LoadResultTest {

    @Test
    @DisplayName("LoadResult exposes documents and failed paths")
    void getters() throws IOException {
        Path temp = Files.createTempFile("loadresult", ".txt");
        temp.toFile().deleteOnExit();
        Files.writeString(temp, "hello");
        Document d = new Document(temp);
        List<Document> docs = List.of(d);
        List<Path> failed = List.of(Paths.get("a.txt"), Paths.get("b.txt"));
        LoadResult r = new LoadResult(docs, failed);
        assertEquals(1, r.getDocuments().size());
        assertEquals(2, r.getFailedPaths().size());
        assertTrue(r.hasFailures());
        assertFalse(r.isEmpty());
    }

    @Test
    @DisplayName("LoadResult null-safe and empty when no docs")
    void emptyAndNullSafe() {
        LoadResult empty = new LoadResult(List.of(), List.of());
        assertTrue(empty.isEmpty());
        assertFalse(empty.hasFailures());
        LoadResult nullDocs = new LoadResult(null, null);
        assertTrue(nullDocs.getDocuments().isEmpty());
        assertTrue(nullDocs.getFailedPaths().isEmpty());
    }
}
