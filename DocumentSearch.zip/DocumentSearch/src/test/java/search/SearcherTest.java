package search;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for all three search strategies.
 *
 * Instead of using real files, we create temporary in-memory files
 * so tests are fast and self-contained.
 */
class SearcherTest {

    // These are our fake documents used across all tests
    private List<Document> documents;

    private StringSearcher  stringSearcher;
    private RegexSearcher   regexSearcher;
    private IndexedSearcher indexedSearcher;

    @BeforeEach
    void setUp() throws IOException {
        // Create two temporary text files with known content
        Path file1 = createTempFile("alpha.txt",
            "The war was long. France fought in the war bravely. War never ends.");

        Path file2 = createTempFile("beta.txt",
            "Peace is better than war. France is a country.");

        documents = List.of(new Document(file1), new Document(file2));

        stringSearcher  = new StringSearcher();
        regexSearcher   = new RegexSearcher();
        indexedSearcher = new IndexedSearcher();
    }

    // ─────────────────────────────────────────────────────────────
    // Tests: word that appears in both documents
    // ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("StringSearch: 'war' appears 3 times in alpha, 1 time in beta")
    void stringSearch_multipleMatches() {
        List<SearchResult> results = stringSearcher.search("war", documents);

        assertEquals(2, results.size(), "Both files should match");
        assertEquals("alpha.txt", results.get(0).getFileName(), "alpha.txt should rank first");
        assertEquals(3, results.get(0).getMatchCount());
        assertEquals(1, results.get(1).getMatchCount());
    }

    @Test
    @DisplayName("RegexSearch: 'war' appears 3 times in alpha, 1 time in beta")
    void regexSearch_multipleMatches() {
        List<SearchResult> results = regexSearcher.search("war", documents);

        assertEquals(2, results.size());
        assertEquals("alpha.txt", results.get(0).getFileName());
        assertEquals(3, results.get(0).getMatchCount());
    }

    @Test
    @DisplayName("IndexedSearch: 'war' appears 3 times in alpha, 1 time in beta")
    void indexedSearch_multipleMatches() {
        List<SearchResult> results = indexedSearcher.search("war", documents);

        assertEquals(2, results.size());
        assertEquals("alpha.txt", results.get(0).getFileName());
        assertEquals(3, results.get(0).getMatchCount());
    }

    // ─────────────────────────────────────────────────────────────
    // Tests: case-insensitive matching
    // ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("StringSearch: case-insensitive — 'WAR' should still match")
    void stringSearch_caseInsensitive() {
        List<SearchResult> results = stringSearcher.search("WAR", documents);
        assertFalse(results.isEmpty(), "Should match regardless of case");
        assertEquals(3, results.get(0).getMatchCount());
    }

    @Test
    @DisplayName("RegexSearch: case-insensitive — 'France' and 'france' both match")
    void regexSearch_caseInsensitive() {
        List<SearchResult> results = regexSearcher.search("France", documents);
        assertEquals(2, results.size());
    }

    // ─────────────────────────────────────────────────────────────
    // Tests: word that appears in only one document
    // ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("All methods: 'peace' only appears in beta.txt")
    void allMethods_singleFileMatch() {
        assertEquals(1, stringSearcher.search("peace", documents).size());
        assertEquals(1, regexSearcher.search("peace", documents).size());
        assertEquals(1, indexedSearcher.search("peace", documents).size());
    }

    // ─────────────────────────────────────────────────────────────
    // Tests: word that doesn't exist
    // ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("All methods: 'xyzzy' returns no results")
    void allMethods_noMatches() {
        assertTrue(stringSearcher.search("xyzzy", documents).isEmpty());
        assertTrue(regexSearcher.search("xyzzy", documents).isEmpty());
        assertTrue(indexedSearcher.search("xyzzy", documents).isEmpty());
    }

    // ─────────────────────────────────────────────────────────────
    // Tests: results are sorted highest-count first
    // ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Results are sorted by match count descending")
    void results_sortedByRelevance() {
        List<SearchResult> results = stringSearcher.search("war", documents);

        // Verify the list is sorted descending
        for (int i = 0; i < results.size() - 1; i++) {
            assertTrue(
                results.get(i).getMatchCount() >= results.get(i + 1).getMatchCount(),
                "Results should be sorted highest match count first"
            );
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Edge cases: empty term, empty list, null safety
    // ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Empty term returns empty results for all searchers")
    void emptyTerm_returnsEmpty() {
        assertTrue(stringSearcher.search("", documents).isEmpty());
        assertTrue(regexSearcher.search("", documents).isEmpty());
        assertTrue(indexedSearcher.search("", documents).isEmpty());
    }

    @Test
    @DisplayName("Null or empty document list returns empty results")
    void emptyDocumentList_returnsEmpty() {
        List<Document> empty = List.of();
        assertTrue(stringSearcher.search("war", empty).isEmpty());
        assertTrue(stringSearcher.search("war", null).isEmpty());
    }

    @Test
    @DisplayName("SearchResult compareTo: descending by count then ascending by name")
    void searchResult_sortOrder() {
        SearchResult a = new SearchResult("a.txt", 1);
        SearchResult b = new SearchResult("b.txt", 2);
        assertTrue(a.compareTo(b) > 0, "higher count should come first");
        assertTrue(b.compareTo(a) < 0);
        SearchResult c = new SearchResult("c.txt", 1);
        assertTrue(a.compareTo(c) < 0, "same count: alphabetical by name");
    }

    // ─────────────────────────────────────────────────────────────
    // Helper: creates a named temp file with given content
    // ─────────────────────────────────────────────────────────────

    private Path createTempFile(String name, String content) throws IOException {
        Path tempDir = Files.createTempDirectory("search_test");
        Path file = tempDir.resolve(name);
        Files.writeString(file, content);
        file.toFile().deleteOnExit();
        return file;
    }
}
